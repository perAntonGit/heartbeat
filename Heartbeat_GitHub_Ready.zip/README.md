# Heartbeat Web V2.4

GitHub Pages ready website.

## Upload
Upload the contents of this folder to a public GitHub repository named:

`heartbeat`

The repository should contain:

- `index.html`
- `assets/`

## Enable GitHub Pages
Repository → Settings → Pages → Source: `main` → Folder: `/root`

Your site will be available at:

`https://YOUR-USERNAME.github.io/heartbeat/`

## Notes
This version uses real Heartbeat photos and local assets only.
